
import React, { useState } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { DiseaseInfo } from '../types';

const HealthEncyclopedia: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<DiseaseInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const searchDisease = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsSearching(true);
    setError(null);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide detailed information about the disease/condition: "${query}". Format as JSON.`,
        config: {
          thinkingConfig: { thinkingBudget: 0 },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
              precautions: { type: Type.ARRAY, items: { type: Type.STRING } },
              riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["name", "description", "symptoms", "precautions", "riskFactors"]
          }
        }
      });

      setResult(JSON.parse(response.text));
    } catch (err) {
      setError("Unable to find information for this condition. Please check the spelling or try another term.");
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold tracking-tight">Health Encyclopedia</h2>
        <p className="text-slate-500 max-w-xl mx-auto">Get verified insights on symptoms, treatments, and precautions for thousands of conditions.</p>
        
        <form onSubmit={searchDisease} className="relative max-w-2xl mx-auto">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search condition (e.g., Type 2 Diabetes, Migraine...)"
            className="w-full bg-white border border-slate-200 rounded-2xl px-6 py-4 pr-16 shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <button
            type="submit"
            disabled={isSearching}
            className="absolute right-2 top-2 bottom-2 bg-blue-600 text-white px-6 rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center"
          >
            {isSearching ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            )}
          </button>
        </form>
      </div>

      {error && <div className="bg-red-50 text-red-600 p-4 rounded-xl border border-red-100 text-center">{error}</div>}

      {result && (
        <div className="glass p-10 rounded-3xl border border-slate-200 space-y-8 animate-in fade-in zoom-in duration-500">
          <header className="border-b border-slate-100 pb-6">
            <h3 className="text-3xl font-bold text-slate-800">{result.name}</h3>
            <p className="text-slate-500 mt-4 leading-relaxed text-lg">{result.description}</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <section className="space-y-4">
              <h4 className="text-xl font-bold flex items-center gap-2 text-blue-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                Key Symptoms
              </h4>
              <ul className="space-y-2">
                {result.symptoms.map((s, i) => (
                  <li key={i} className="flex gap-3 text-slate-600">
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0"></span>
                    {s}
                  </li>
                ))}
              </ul>
            </section>

            <section className="space-y-4">
              <h4 className="text-xl font-bold flex items-center gap-2 text-emerald-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
                Precautions
              </h4>
              <ul className="space-y-2">
                {result.precautions.map((p, i) => (
                  <li key={i} className="flex gap-3 text-slate-600">
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0"></span>
                    {p}
                  </li>
                ))}
              </ul>
            </section>
          </div>

          <section className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <h4 className="font-bold text-slate-700 mb-3">Risk Factors</h4>
            <div className="flex flex-wrap gap-2">
              {result.riskFactors.map((r, i) => (
                <span key={i} className="bg-white px-3 py-1.5 rounded-lg border border-slate-200 text-sm text-slate-500">#{r}</span>
              ))}
            </div>
          </section>

          <footer className="text-center text-xs text-slate-400 border-t border-slate-100 pt-6">
            Information provided by Aura AI is based on general medical data and should not replace professional medical advice.
          </footer>
        </div>
      )}

      {!result && !isSearching && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Flu', 'Asthma', 'Arthritis', 'Hypertension'].map(tag => (
            <button key={tag} onClick={() => {setQuery(tag);}} className="p-4 bg-white border border-slate-200 rounded-2xl text-slate-500 hover:border-blue-400 hover:text-blue-600 transition-all font-medium">
              {tag}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default HealthEncyclopedia;
