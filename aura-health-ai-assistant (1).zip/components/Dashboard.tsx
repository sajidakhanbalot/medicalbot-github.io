
import React from 'react';
import { AppTab } from '../types';

interface DashboardProps {
  onNavigate: (tab: AppTab) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  return (
    <div className="animate-in fade-in duration-700 space-y-8">
      <section className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden shadow-2xl shadow-blue-200">
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Your Virtual AI Health Companion.</h1>
          <p className="text-blue-100 text-lg mb-8 leading-relaxed">
            Analyze medicines, chat via voice, learn about diseases, and book specialist consultations — all in one place.
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => onNavigate(AppTab.SCANNER)}
              className="bg-white text-blue-600 px-6 py-3 rounded-full font-bold hover:bg-blue-50 transition-all shadow-lg active:scale-95 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              </svg>
              Scan Medicine
            </button>
            <button 
              onClick={() => onNavigate(AppTab.VOICE)}
              className="bg-blue-500 bg-opacity-30 backdrop-blur-md text-white border border-blue-400 px-6 py-3 rounded-full font-bold hover:bg-opacity-40 transition-all flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
              Voice Talk
            </button>
          </div>
        </div>
        <div className="absolute right-[-10%] bottom-[-20%] w-[400px] h-[400px] bg-white opacity-10 rounded-full blur-3xl"></div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group" onClick={() => onNavigate(AppTab.ENCYCLOPEDIA)}>
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
          </div>
          <h3 className="text-xl font-bold mb-2">Disease Library</h3>
          <p className="text-slate-500 text-sm">Find accurate details on common ailments, symptoms, and treatment guidelines.</p>
        </div>

        <div className="glass p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group" onClick={() => onNavigate(AppTab.BOOKING)}>
          <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-xl font-bold mb-2">Book a Session</h3>
          <p className="text-slate-500 text-sm">Schedule high-priority consultations with certified specialists in minutes.</p>
        </div>

        <div className="glass p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-10.426A7.243 7.243 0 0111.242 3h1.516a7.243 7.243 0 017.435 7.571c0 3.517-1.009 6.799-2.753 9.571m-1.44-10.426a7.243 7.243 0 01-7.435-7.571" />
            </svg>
          </div>
          <h3 className="text-xl font-bold mb-2">Smart History</h3>
          <p className="text-slate-500 text-sm">Track your scanned medicines and previous health queries securely.</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 py-10">
        <div className="space-y-4">
          <h2 className="text-3xl font-bold">Why Aura?</h2>
          <div className="space-y-4">
            {[
              { title: 'AI-Powered Precision', desc: 'Gemini 3 models ensure highly accurate health insights.' },
              { title: 'Privacy First', desc: 'Your medical data is yours. We use high-end encryption.' },
              { title: '24/7 Availability', desc: 'Our AI agent never sleeps. Help is always one tap away.' },
            ].map((item, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">{item.title}</h4>
                  <p className="text-slate-500 text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl overflow-hidden shadow-xl aspect-video relative">
          <img src="https://picsum.photos/seed/health1/800/600" alt="Health" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-8">
            <p className="text-white font-medium italic">"The future of healthcare is accessible, intelligent, and personalized."</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
