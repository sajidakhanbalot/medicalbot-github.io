
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

const VoiceAssistant: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcriptions, setTranscriptions] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [transcriptions]);

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let ch = 0; ch < numChannels; ch++) {
      const chData = buffer.getChannelData(ch);
      for (let i = 0; i < frameCount; i++) chData[i] = dataInt16[i * numChannels + ch] / 32768.0;
    }
    return buffer;
  };

  const startSession = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;

      let nextStartTime = 0;
      let currentInput = '';
      let currentOutput = '';

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const data = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(data.length);
              for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
              const blob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(s => s.sendRealtimeInput({ media: blob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.inputTranscription) currentInput += msg.serverContent.inputTranscription.text;
            if (msg.serverContent?.outputTranscription) currentOutput += msg.serverContent.outputTranscription.text;
            
            if (msg.serverContent?.turnComplete) {
              setTranscriptions(prev => [...prev, `You: ${currentInput}`, `Aura: ${currentOutput}`]);
              currentInput = '';
              currentOutput = '';
            }

            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              nextStartTime = Math.max(nextStartTime, outputCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTime);
              nextStartTime += buffer.duration;
            }
          },
          onerror: (e) => setError("Audio connection error."),
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: "You are Aura, a friendly virtual health assistant. You are empathetic, concise, and helpful. Always remind the user you are an AI and not a doctor."
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      setError("Failed to start voice session. Please allow microphone access.");
    }
  };

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    setIsActive(false);
  };

  return (
    <div className="max-w-3xl mx-auto h-[70vh] flex flex-col gap-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Aura Live Voice</h2>
        <p className="text-slate-500">Instant health support through voice. Just speak.</p>
      </div>

      <div className="flex-1 glass rounded-3xl border border-slate-200 p-6 flex flex-col shadow-sm relative overflow-hidden">
        <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pr-2">
          {transcriptions.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4 opacity-50">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
              <p>Start the conversation to see transcriptions.</p>
            </div>
          ) : (
            transcriptions.map((t, i) => (
              <div key={i} className={`p-4 rounded-2xl max-w-[85%] ${t.startsWith('You:') ? 'bg-blue-600 text-white self-end ml-auto' : 'bg-slate-100 text-slate-700'}`}>
                {t}
              </div>
            ))
          )}
        </div>

        {isActive && (
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="w-1.5 h-8 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s`, height: `${10 + Math.random() * 30}px` }}></div>
            ))}
          </div>
        )}
      </div>

      <div className="flex justify-center">
        {!isActive ? (
          <button 
            onClick={startSession}
            className="group relative flex items-center justify-center"
          >
            <div className="absolute inset-0 bg-blue-400 rounded-full blur-xl group-hover:blur-2xl transition-all opacity-40 animate-pulse"></div>
            <div className="relative bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-110 active:scale-95">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
            </div>
            <span className="absolute -bottom-10 whitespace-nowrap font-bold text-blue-600">Start Calling Aura</span>
          </button>
        ) : (
          <button 
            onClick={stopSession}
            className="bg-red-500 text-white px-8 py-4 rounded-full font-bold shadow-lg hover:bg-red-600 transition-all flex items-center gap-2 active:scale-95"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            End Conversation
          </button>
        )}
      </div>

      {error && <div className="text-center text-red-500 text-sm font-medium">{error}</div>}
    </div>
  );
};

export default VoiceAssistant;
