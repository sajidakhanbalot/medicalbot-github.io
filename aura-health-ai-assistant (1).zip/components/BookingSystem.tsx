
import React, { useState } from 'react';
import { Booking } from '../types';

const BookingSystem: React.FC = () => {
  const [step, setStep] = useState(1);
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);

  const specialties = [
    { id: 'gp', name: 'General Physician', icon: '🩺' },
    { id: 'cardio', name: 'Cardiologist', icon: '❤️' },
    { id: 'derm', name: 'Dermatologist', icon: '🧴' },
    { id: 'neuro', name: 'Neurologist', icon: '🧠' },
    { id: 'ortho', name: 'Orthopedic', icon: '🦴' },
    { id: 'psych', name: 'Psychiatrist', icon: '🧘' },
  ];

  const handleBooking = () => {
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      doctorName: `Dr. ${['Smith', 'Johnson', 'Wong', 'Garcia'][Math.floor(Math.random() * 4)]}`,
      specialty: selectedSpecialty,
      date: selectedDate,
      time: '10:00 AM'
    };
    setBookings([newBooking, ...bookings]);
    setStep(3);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-bold">Booking Hub</h2>
          <p className="text-slate-500">Fast-track your consultation with experts.</p>
        </div>
        <div className="flex gap-1">
          {[1, 2, 3].map(s => (
            <div key={s} className={`w-10 h-1.5 rounded-full transition-all ${step >= s ? 'bg-blue-600' : 'bg-slate-200'}`}></div>
          ))}
        </div>
      </header>

      {step === 1 && (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
          <h3 className="text-xl font-bold">Choose Specialty</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {specialties.map(spec => (
              <button
                key={spec.id}
                onClick={() => { setSelectedSpecialty(spec.name); setStep(2); }}
                className="glass p-6 rounded-3xl border-2 border-transparent hover:border-blue-500 hover:shadow-lg transition-all text-center space-y-2 group"
              >
                <div className="text-4xl group-hover:scale-125 transition-transform">{spec.icon}</div>
                <div className="font-bold text-slate-800">{spec.name}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
          <button onClick={() => setStep(1)} className="text-blue-600 text-sm font-bold flex items-center gap-1 hover:underline">
            ← Change Specialty ({selectedSpecialty})
          </button>
          <div className="glass p-8 rounded-3xl border border-slate-200 space-y-6">
            <h3 className="text-xl font-bold">Select Date & Time</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input 
                type="date" 
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <div className="grid grid-cols-2 gap-2">
                {['09:00 AM', '11:00 AM', '02:00 PM', '04:00 PM'].map(time => (
                  <button key={time} className="p-4 bg-white border border-slate-200 rounded-xl hover:bg-blue-50 hover:border-blue-500 text-sm font-medium transition-all">
                    {time}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={handleBooking}
              disabled={!selectedDate}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Confirm Appointment
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="text-center space-y-6 animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-4xl">
            ✓
          </div>
          <div className="space-y-2">
            <h3 className="text-3xl font-bold">Session Booked!</h3>
            <p className="text-slate-500">You will receive an email confirmation and a calendar invite shortly.</p>
          </div>
          <button onClick={() => setStep(1)} className="bg-slate-800 text-white px-8 py-3 rounded-full font-bold hover:bg-slate-900 transition-all">
            Book Another
          </button>
        </div>
      )}

      {bookings.length > 0 && (
        <div className="space-y-6 pt-10 border-t border-slate-200">
          <h3 className="text-2xl font-bold">Your Upcoming Sessions</h3>
          <div className="space-y-4">
            {bookings.map(b => (
              <div key={b.id} className="glass p-6 rounded-2xl border border-slate-200 flex justify-between items-center group">
                <div className="flex gap-4 items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-xl">👨‍⚕️</div>
                  <div>
                    <h4 className="font-bold text-slate-800">{b.doctorName}</h4>
                    <p className="text-slate-500 text-sm">{b.specialty}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-slate-800">{b.date}</div>
                  <div className="text-slate-500 text-sm">{b.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingSystem;
