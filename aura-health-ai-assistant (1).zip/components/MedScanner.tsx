
import React, { useState, useRef } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { MedicineAnalysis } from '../types';

const MedScanner: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<MedicineAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeMedicine = async () => {
    if (!image) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const base64Data = image.split(',')[1];

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
            { text: "Analyze this medicine image. Identify the medicine and provide details in JSON format." }
          ]
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              activeIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
              commonUses: { type: Type.ARRAY, items: { type: Type.STRING } },
              dosageInstructions: { type: Type.STRING },
              warnings: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["name", "activeIngredients", "commonUses", "dosageInstructions", "warnings"]
          }
        }
      });

      const parsedResult = JSON.parse(response.text);
      setResult(parsedResult);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze the medicine. Please ensure the image is clear.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">MedScan AI</h2>
        <p className="text-slate-500">Upload a clear photo of your medicine bottle or pill.</p>
      </div>

      <div className="glass border-2 border-dashed border-slate-300 rounded-3xl p-8 flex flex-col items-center justify-center min-h-[300px] gap-4">
        {image ? (
          <div className="relative group">
            <img src={image} alt="Medication" className="max-h-64 rounded-2xl shadow-lg border border-slate-200" />
            <button 
              onClick={() => { setImage(null); setResult(null); }}
              className="absolute -top-3 -right-3 bg-red-500 text-white rounded-full p-2 hover:bg-red-600 transition-colors shadow-lg"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 text-slate-400">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              </svg>
            </div>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="text-blue-600 font-semibold hover:underline"
            >
              Select Image from Gallery or Camera
            </button>
          </div>
        )}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept="image/*" 
          className="hidden" 
        />
        
        {image && !result && (
          <button
            onClick={analyzeMedicine}
            disabled={isAnalyzing}
            className={`mt-4 w-full bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 ${isAnalyzing ? 'opacity-70 cursor-not-allowed' : 'active:scale-95'}`}
          >
            {isAnalyzing ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Analyzing with Gemini...
              </>
            ) : 'Start Analysis'}
          </button>
        )}
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl border border-red-100 text-sm">
          {error}
        </div>
      )}

      {result && (
        <div className="glass p-8 rounded-3xl border border-slate-200 animate-in slide-in-from-bottom-4 duration-500 space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-2xl font-bold text-blue-600">{result.name}</h3>
              <p className="text-slate-500 text-sm">Identified Medication</p>
            </div>
            <span className="bg-blue-100 text-blue-700 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full">AI Verified</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-slate-700 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div> Active Ingredients
                </h4>
                <div className="flex flex-wrap gap-2 mt-2">
                  {result.activeIngredients.map((ing, i) => (
                    <span key={i} className="bg-slate-100 text-slate-600 text-xs px-2 py-1 rounded-md">{ing}</span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-bold text-slate-700 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div> Common Uses
                </h4>
                <p className="text-slate-600 text-sm mt-1">{result.commonUses.join(", ")}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h4 className="font-bold text-slate-700 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500"></div> Dosage
                </h4>
                <p className="text-slate-600 text-sm mt-1 leading-relaxed">{result.dosageInstructions}</p>
              </div>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl">
            <h4 className="font-bold text-amber-800 flex items-center gap-2 mb-2 text-sm">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
              Safety Warnings
            </h4>
            <ul className="list-disc list-inside text-xs text-amber-700 space-y-1">
              {result.warnings.map((w, i) => <li key={i}>{w}</li>)}
              <li className="font-bold mt-2">IMPORTANT: Always consult with a doctor before taking any medication. AI results are for reference only.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default MedScanner;
